// Java Program to Illustrate DepartmentController.java File

// Importing packages modules
package com.sample.springdemo.controller;

import com.sample.springdemo.entity.Sample;
import com.sample.springdemo.service.SampleService;
import java.util.List;
// Importing required classes
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

// Annotation
@RestController
// Class
public class SampleController {

  @Autowired
  private SampleService sampleService;

  // Save operation
  @PostMapping("/saveSample")

  public Department saveSample(
      @Valid @RequestBody Sample sample) {
    return sampleService.saveSample(sample);
  }

  // Read operation
  @GetMapping("/getSample")

  public List<Sample> fetchSampleList() {
    return SampleService.fetchSampleList();
  }

  // Update operation
  @PutMapping("/updateSample/{id}")

  public Sample
  updateSample(@RequestBody Sample sample,
      @PathVariable("id") Long Id) {
    return sampleService.updateSample(
        sample, id);
  }

  // Delete operation
  @DeleteMapping("/deleteSample/{id}")

  public String deleteSampleById(@PathVariable("id")
      Long id) {
    sampleService.deleteSampleById(
        id);
    return "Deleted Successfully";
  }
}
