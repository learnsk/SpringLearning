// Java Program to Illustrate SampleService.java File

// Importing packages
package com.sample.springdemo.service;

import com.sample.springdemo.entity.Sample;
// Importing required classes
import java.util.List;

// Class
public interface SampleService {

  // Save operation
  Sample saveSample(Sample sample);

  // Read operation
  List<Sample> fetchDepartmentList();

  // Update operation
  Sample updateSample(Sample sample,
      Long id);

  // Delete operation
  void deleteSampleById(Long id);
}
