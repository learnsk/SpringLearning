// Java Program to Illustrate SampleServiceImpl.java
// File

// Importing required packages
package com.sample.springdemo.service;

import com.sample.springdemo.entity.Sample;
import com.sample.springdemo.repository.sampleRepository;
// Importing required classes
import java.util.List;
import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// Annotation
@Service
// Class implementing SampleService class
public class SampleServiceImpl
    implements SampleService {

  @Autowired
  private Sample sampleRepository;

  // Save operation
  @Override
  public Sample saveSample(Sample sample) {
    return sampleRepository.save(sample);
  }

  // Read operation
  @Override
  public List<Sample> fetchsampleList() {
    return (List<Sample>)
        sampleRepository.findAll();
  }

  // Update operation
  @Override
  public Sample
  updatesample(Sample sample,
      Long id) {

    Sample depDB
        = sampleRepository.findById(id)
        .get();

    if (Objects.nonNull(sample.getsampleName())
        && !"".equalsIgnoreCase(
        sample.getName())) {
      depDB.setName(
          sample.getName());
    }

    if (Objects.nonNull(
        sample.getSampleAddress())
        && !"".equalsIgnoreCase(
        sample.getAddress())) {
      depDB.setAddress(
          sample.getAddress());
    }

    if (Objects.nonNull(sample.getCode())
        && !"".equalsIgnoreCase(
        sample.getCode())) {
      depDB.setCode(
          sample.getCode());
    }

    return sampleRepository.save(depDB);
  }

  // Delete operation
  @Override
  public void deleteSampleById(Long id) {
    sampleRepository.deleteById(id);
  }
}
